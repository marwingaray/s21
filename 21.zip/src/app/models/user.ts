export interface User {
    usuario:string,
    password: string
}
